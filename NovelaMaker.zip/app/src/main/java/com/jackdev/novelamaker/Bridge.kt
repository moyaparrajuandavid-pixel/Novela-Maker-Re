package com.jackdev.novelamaker

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/** Puente entre la página de Novela Maker y la app. */
class Bridge(private val ctx: Context, private val onRestore: (Int, Int, Int) -> Unit) {
    // --- exportar archivos a Descargas ---
    private var out: OutputStream? = null
    private var uri: Uri? = null
    private var fileName = ""

    // --- respaldo automático ---
    private var bkOut: OutputStream? = null
    private var bkId = ""
    private var bkName = ""
    private val bkTemp: File get() = File(ctx.cacheDir, "bk.tmp")

    @JavascriptInterface
    fun setProjects(json: String) {
        ctx.getSharedPreferences("nm", Context.MODE_PRIVATE).edit().putString("projects", json).apply()
    }

    @JavascriptInterface
    fun saveChunk(name: String, mime: String, first: Boolean, b64: String, last: Boolean) {
        try {
            if (first) { closeQuiet(); openOut(name, mime) }
            out?.write(Base64.decode(b64, Base64.DEFAULT))
            if (last) {
                out?.flush()
                closeQuiet()
                markDone()
                toast("Guardado en Descargas/NovelaMaker: $fileName")
            }
        } catch (e: Exception) {
            closeQuiet()
            toast("No se pudo guardar el archivo")
        }
    }

    @JavascriptInterface
    fun backedIds(): String = Backup.ids(ctx)

    @JavascriptInterface
    fun backupChunk(id: String, name: String, first: Boolean, b64: String, last: Boolean) {
        try {
            if (first) {
                try { bkOut?.close() } catch (e: Exception) { }
                bkOut = FileOutputStream(bkTemp)
                bkId = id
                bkName = name
            }
            bkOut?.write(Base64.decode(b64, Base64.DEFAULT))
            if (last) {
                bkOut?.close()
                bkOut = null
                Backup.save(ctx, bkId, bkName, bkTemp)
                bkTemp.delete()
            }
        } catch (e: Exception) {
            try { bkOut?.close() } catch (x: Exception) { }
            bkOut = null
        }
    }

    @JavascriptInterface
    fun backupDone(n: Int, manual: Boolean) {
        if (manual) toast(if (n > 0) "Respaldo listo: $n proyecto(s) en Documentos/NovelaMaker/Respaldo" else "No hay proyectos para respaldar")
    }

    @JavascriptInterface
    fun markBacked(id: String, name: String) { Backup.mark(ctx, id, name) }

    @JavascriptInterface
    fun restoreDone(ok: Int, skip: Int, bad: Int) { onRestore(ok, skip, bad) }

    private fun openOut(name: String, mime: String) {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "novela" }
        fileName = safe
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NovelaMaker")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("sin destino")
            uri = u
            out = ctx.contentResolver.openOutputStream(u)
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NovelaMaker")
            dir.mkdirs()
            out = FileOutputStream(File(dir, safe))
        }
    }

    private fun markDone() {
        val u = uri
        if (u != null && Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            ctx.contentResolver.update(u, v, null, null)
        }
        uri = null
    }

    private fun closeQuiet() {
        try { out?.close() } catch (e: Exception) { }
        out = null
    }

    private fun toast(msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() }
    }
}
