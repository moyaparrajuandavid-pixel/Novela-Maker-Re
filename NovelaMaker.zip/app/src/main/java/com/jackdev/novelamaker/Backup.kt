package com.jackdev.novelamaker

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Respaldos de proyectos en Documentos/NovelaMaker/Respaldo (sobreviven aunque desinstales la app). */
object Backup {
    private const val BASE = "Documents/NovelaMaker/Respaldo"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nm", Context.MODE_PRIVATE)

    private fun map(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString("bk_files", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }

    fun ids(ctx: Context): String {
        val keys = map(ctx).keys().asSequence().toList()
        return JSONArray(keys).toString()
    }

    fun fileName(name: String, id: String): String {
        val n = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(40).ifBlank { "Proyecto" }
        val i = id.replace(Regex("[^A-Za-z0-9]"), "").take(12)
        return "${n}_$i.json"
    }

    /** Marca un proyecto restaurado como ya respaldado (para no duplicar el archivo). */
    fun mark(ctx: Context, id: String, name: String) {
        val m = map(ctx)
        m.put(id, fileName(name, id))
        prefs(ctx).edit().putString("bk_files", m.toString()).apply()
    }

    fun save(ctx: Context, id: String, name: String, temp: File): Boolean {
        val m = map(ctx)
        val newName = fileName(name, id)
        val old = m.optString(id, "")
        if (old.isNotEmpty() && old != newName) delete(ctx, old)
        val ok = write(ctx, newName, temp)
        if (ok) {
            m.put(id, newName)
            prefs(ctx).edit().putString("bk_files", m.toString()).apply()
        }
        return ok
    }

    private fun filesUri(): Uri = MediaStore.Files.getContentUri("external")

    private fun find(ctx: Context, name: String): Uri? {
        val col = filesUri()
        val sel = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
        ctx.contentResolver.query(col, arrayOf(MediaStore.MediaColumns._ID), sel, arrayOf(name, "$BASE/"), null)?.use { c ->
            if (c.moveToFirst()) return android.content.ContentUris.withAppendedId(col, c.getLong(0))
        }
        return null
    }

    private fun delete(ctx: Context, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val u = find(ctx, name)
                if (u != null) ctx.contentResolver.delete(u, null, null)
            } else {
                File(dirLegacy(), name).delete()
            }
        } catch (e: Exception) { }
    }

    private fun dirLegacy(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "NovelaMaker/Respaldo")

    private fun write(ctx: Context, name: String, temp: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val existing = find(ctx, name)
                val uri = existing ?: ctx.contentResolver.insert(filesUri(), ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, BASE)
                }) ?: return false
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    temp.inputStream().use { it.copyTo(out) }
                }
            } else {
                val dir = dirLegacy()
                dir.mkdirs()
                temp.copyTo(File(dir, name), overwrite = true)
            }
            true
        } catch (e: Exception) { false }
    }
}
