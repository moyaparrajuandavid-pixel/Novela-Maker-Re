package com.jackdev.novelamaker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Busca en GitHub si hay una versión más nueva de la app y avisa dentro de la app. */
object Updater {
    /** Usuario/repositorio donde se publican las APK (el repositorio debe ser público). */
    const val REPO = "moyaparrajuandavid-pixel/Novela-Maker-Re"

    fun check(act: Activity) {
        Thread {
            try {
                val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "NovelaMaker")
                if (c.responseCode == 200) {
                    val j = JSONObject(c.inputStream.bufferedReader().readText())
                    val tag = j.optString("tag_name").removePrefix("v")
                    val url = j.optString("html_url")
                    val notes = j.optString("body")
                    val current = act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "0"
                    if (tag.isNotBlank() && url.isNotBlank() && newer(tag, current)) {
                        act.runOnUiThread { announce(act, tag, url, notes) }
                    }
                }
            } catch (e: Exception) { }
        }.start()
    }

    private fun newer(a: String, b: String): Boolean {
        val x = a.split(".").map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }
            val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    private fun announce(act: Activity, tag: String, url: String, notes: String) {
        if (act.isFinishing || act.isDestroyed) return
        val open = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        AlertDialog.Builder(act)
            .setTitle("Nueva actualización disponible")
            .setMessage("Versión $tag\n\n" + notes.ifBlank { "Hay cambios y mejoras nuevas." })
            .setPositiveButton("Descargar") { _, _ -> act.startActivity(open) }
            .setNegativeButton("Más tarde", null)
            .show()
        val sp = act.getSharedPreferences("nm", Context.MODE_PRIVATE)
        if (sp.getString("upd_notified", "") != tag) {
            Notif.send(act, "Novela Maker", "Nueva actualización disponible: versión $tag", open)
            sp.edit().putString("upd_notified", tag).apply()
        }
    }
}
