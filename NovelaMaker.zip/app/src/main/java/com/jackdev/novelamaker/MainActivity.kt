package com.jackdev.novelamaker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val REQ_FILE = 11
    private val REQ_PERM = 12
    private var paused = false

    private val syncTick = object : Runnable {
        override fun run() {
            syncProjects()
            handler.postDelayed(this, 60000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView?, url: String?) {
                handler.postDelayed({ syncProjects() }, 4000)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("Aceptar") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancelar") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton("Aceptar") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancelar") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        web.addJavascriptInterface(Bridge(applicationContext), "NMBridge")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        askPermissions()
        Updater.check(this)
    }

    private fun neededPermissions(): List<String> {
        val all = if (Build.VERSION.SDK_INT >= 33) {
            listOf(
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else if (Build.VERSION.SDK_INT >= 29) {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return all.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun askPermissions() {
        val missing = neededPermissions()
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        afterPermissions()
    }

    /** Programa los recordatorios y manda la notificación de prueba la primera vez que se puede. */
    private fun afterPermissions() {
        Notif.schedule(this)
        val sp = getSharedPreferences("nm", Context.MODE_PRIVATE)
        if (Notif.enabled(this) && !sp.getBoolean("welcomed", false)) {
            Notif.send(this, "Novela Maker", "Empecemos forzando tus habilidades")
            sp.edit().putBoolean("welcomed", true).apply()
        }
    }

    /** Lee los nombres de los proyectos guardados en el editor para usarlos en los recordatorios. */
    private fun syncProjects() {
        val js = "(function(){try{var q=indexedDB.open('novelamaker',1);" +
            "q.onupgradeneeded=function(){q.result.createObjectStore('p',{keyPath:'id'})};" +
            "q.onsuccess=function(){try{var db=q.result;if(!db.objectStoreNames.contains('p')){return}" +
            "var names=[];var c=db.transaction('p','readonly').objectStore('p').openCursor();" +
            "c.onsuccess=function(e){var cur=e.target.result;if(cur){var n=cur.value&&cur.value.name;" +
            "if(n)names.push(String(n));cur.continue()}else{NMBridge.setProjects(JSON.stringify(names))}}}catch(e){}}}catch(e){}})()"
        web.evaluateJavascript(js, null)
    }

    override fun onResume() {
        super.onResume()
        paused = false
        web.onResume()
        afterPermissions()
        handler.postDelayed(syncTick, 60000)
    }

    override fun onPause() {
        syncProjects()
        handler.removeCallbacks(syncTick)
        paused = true
        handler.postDelayed({ if (paused) web.onPause() }, 1500)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
