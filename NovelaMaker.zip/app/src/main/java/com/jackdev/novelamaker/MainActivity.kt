package com.jackdev.novelamaker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val REQ_FILE = 11
    private val REQ_PERM = 12
    private val REQ_TREE = 13
    private var restoreList: List<Uri> = emptyList()
    private var paused = false

    private val syncTick = object : Runnable {
        override fun run() {
            syncProjects()
            handler.postDelayed(this, 60000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyOrientation(orientationMode())
        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        buildRotateButton(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = true

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/restore/", WebViewAssetLoader.PathHandler { path ->
                val i = path.substringBefore(".").toIntOrNull()
                val u = if (i != null) restoreList.getOrNull(i) else null
                if (u == null) null else try {
                    WebResourceResponse("application/json", "utf-8", contentResolver.openInputStream(u))
                } catch (e: Exception) { null }
            })
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun onPageFinished(view: WebView?, url: String?) {
                handler.postDelayed({ syncProjects() }, 4000)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("Aceptar") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancelar") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton("Aceptar") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancelar") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        web.addJavascriptInterface(Bridge(applicationContext) { ok, skip, bad -> onRestoreDone(ok, skip, bad) }, "NMBridge")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        askPermissions()
        Updater.check(this)
    }

    // ---------- Orientación: 0 = automática, 1 = vertical, 2 = horizontal ----------
    private fun orientationMode(): Int = getSharedPreferences("nm", Context.MODE_PRIVATE).getInt("orient", 0)

    private fun applyOrientation(mode: Int) {
        requestedOrientation = when (mode) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun showMenu() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        val items = arrayOf("Orientación de la pantalla", "Respaldar proyectos ahora", "Restaurar proyectos")
        AlertDialog.Builder(this)
            .setTitle("Novela Maker $ver")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> chooseOrientation()
                    1 -> web.evaluateJavascript("nmFlush(true)", null)
                    2 -> startRestore()
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun startRestore() {
        AlertDialog.Builder(this)
            .setTitle("Restaurar proyectos")
            .setMessage("Elige la carpeta Documentos > NovelaMaker > Respaldo y toca \"Usar esta carpeta\". Se recuperan los proyectos que no estén ya en la app.")
            .setPositiveButton("Elegir carpeta") { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                i.putExtra(
                    DocumentsContract.EXTRA_INITIAL_URI,
                    DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:Documents/NovelaMaker/Respaldo")
                )
                try { startActivityForResult(i, REQ_TREE) } catch (e: Exception) {
                    Toast.makeText(this, "No se pudo abrir el selector de carpetas", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun onRestoreDone(ok: Int, skip: Int, bad: Int) {
        runOnUiThread {
            val msg = if (ok > 0) "Se restauraron $ok proyecto(s)" + (if (skip > 0) " ($skip ya estaban)" else "")
            else if (skip > 0) "Todos los proyectos ya estaban en la app"
            else "No se pudo restaurar nada" + (if (bad > 0) " ($bad archivo(s) inválidos)" else "")
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            if (ok > 0) web.reload()
        }
    }

    private fun chooseOrientation() {
        val names = arrayOf("Automática (sigue al celular)", "Vertical", "Horizontal")
        AlertDialog.Builder(this)
            .setTitle("Orientación de la pantalla")
            .setSingleChoiceItems(names, orientationMode()) { d, which ->
                getSharedPreferences("nm", Context.MODE_PRIVATE).edit().putInt("orient", which).apply()
                applyOrientation(which)
                Toast.makeText(this, names[which], Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    /** Botón ⟳ flotante: toca para elegir la orientación, arrástralo para moverlo. */
    private fun buildRotateButton(root: FrameLayout) {
        val dp = resources.displayMetrics.density
        val size = (44 * dp).toInt()
        val sp = getSharedPreferences("nm", Context.MODE_PRIVATE)
        val b = TextView(this).apply {
            text = "⚙"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            alpha = 0.6f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1A1428.toInt())
                setStroke((2 * dp).toInt(), 0xFFFF69A8.toInt())
            }
        }
        root.addView(b, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START))

        fun place() {
            val fx = sp.getFloat("btn_x", 1f)
            val fy = sp.getFloat("btn_y", 0.35f)
            b.x = fx * (root.width - size).coerceAtLeast(0)
            b.y = fy * (root.height - size).coerceAtLeast(0)
        }
        root.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob ->
            if (r - l != orr - ol || bt - t != ob - ot) place()
        }
        root.post { place() }

        var downX = 0f
        var downY = 0f
        var startX = 0f
        var startY = 0f
        var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = v.x; startY = v.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        v.x = (startX + dx).coerceIn(0f, (root.width - v.width).toFloat())
                        v.y = (startY + dy).coerceIn(0f, (root.height - v.height).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val w = (root.width - v.width).coerceAtLeast(1)
                        val h = (root.height - v.height).coerceAtLeast(1)
                        sp.edit().putFloat("btn_x", v.x / w).putFloat("btn_y", v.y / h).apply()
                    } else {
                        showMenu()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun neededPermissions(): List<String> {
        val all = if (Build.VERSION.SDK_INT >= 33) {
            listOf(
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else if (Build.VERSION.SDK_INT >= 29) {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return all.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun askPermissions() {
        val missing = neededPermissions()
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), REQ_PERM)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        afterPermissions()
    }

    /** Programa los recordatorios y manda la notificación de prueba la primera vez que se puede. */
    private fun afterPermissions() {
        Notif.schedule(this)
        val sp = getSharedPreferences("nm", Context.MODE_PRIVATE)
        if (Notif.enabled(this) && !sp.getBoolean("welcomed", false)) {
            Notif.send(this, "Novela Maker", "Empecemos forzando tus habilidades")
            sp.edit().putBoolean("welcomed", true).apply()
        }
    }

    /** Lee los nombres de los proyectos guardados en el editor para usarlos en los recordatorios. */
    private fun syncProjects() {
        val js = "(function(){try{var q=indexedDB.open('novelamaker',1);" +
            "q.onupgradeneeded=function(){q.result.createObjectStore('p',{keyPath:'id'})};" +
            "q.onsuccess=function(){try{var db=q.result;if(!db.objectStoreNames.contains('p')){return}" +
            "var names=[];var c=db.transaction('p','readonly').objectStore('p').openCursor();" +
            "c.onsuccess=function(e){var cur=e.target.result;if(cur){var n=cur.value&&cur.value.name;" +
            "if(n)names.push(String(n));cur.continue()}else{NMBridge.setProjects(JSON.stringify(names))}}}catch(e){}}}catch(e){}})()"
        web.evaluateJavascript(js, null)
    }

    override fun onResume() {
        super.onResume()
        paused = false
        web.onResume()
        afterPermissions()
        handler.postDelayed(syncTick, 60000)
    }

    override fun onPause() {
        syncProjects()
        web.evaluateJavascript(
            "(function(){try{nmFlush(false)}catch(e){}try{document.querySelectorAll('audio,video').forEach(function(a){a.pause()})}catch(e){}})()",
            null
        )
        handler.removeCallbacks(syncTick)
        paused = true
        handler.postDelayed({ if (paused) web.onPause() }, 8000)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        }
        if (requestCode == REQ_TREE && resultCode == RESULT_OK && data?.data != null) {
            val tree = data.data!!
            val found = ArrayList<Pair<Uri, Long>>()
            try {
                val docId = DocumentsContract.getTreeDocumentId(tree)
                val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
                val cols = arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                )
                contentResolver.query(children, cols, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(1) ?: ""
                        if (name.endsWith(".json", true)) {
                            found.add(Pair(DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)), c.getLong(2)))
                        }
                    }
                }
            } catch (e: Exception) { }
            if (found.isEmpty()) {
                Toast.makeText(this, "No encontré respaldos (.json) en esa carpeta", Toast.LENGTH_LONG).show()
            } else {
                // los más recientes primero, para que ganen si hay copias repetidas
                restoreList = found.sortedByDescending { it.second }.map { it.first }
                web.evaluateJavascript("nmRestore(${restoreList.size})", null)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
