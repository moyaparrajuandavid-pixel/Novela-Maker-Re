package com.jackdev.novelamaker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import java.util.concurrent.TimeUnit

object Notif {
    private const val CH = "nm_reminders"

    /** {p} se reemplaza por el nombre de uno de tus proyectos. */
    val MESSAGES = listOf(
        "Tienes un proyecto que terminar",
        "Tu proyecto «{p}» aún le faltan unos retoques",
        "Oye, tienes talento. ¡Ve y termínalo!",
        "Tu historia está esperando. ¿Escribimos una escena más?",
        "«{p}» te extraña. Vuelve y dale vida a la siguiente escena",
        "Una escena al día y en poco tiempo tendrás una novela completa",
        "Hoy es buen día para crear un final inolvidable",
        "¿Y si tus personajes tomaran hoy una decisión importante?",
        "Los mejores autores empezaron igual que tú. ¡Sigue creando!",
        "«{p}» está más cerca de terminarse de lo que crees",
        "Tus personajes preguntan por ti. ¿Les escribes un diálogo nuevo?",
        "Un fondo nuevo, una música perfecta… tu novela lo agradecerá",
        "Reserva 10 minutos hoy para tu novela. Vale la pena",
        "¿Ya probaste cambiar la caja de diálogo? Puede darle un estilo único",
        "Tu proyecto «{p}» merece un buen cierre. ¡Tú puedes!",
        "Las grandes historias se hacen escena por escena",
        "¿Has pensado en una ramificación sorpresa para «{p}»?",
        "Tu imaginación es tu mejor herramienta. Úsala hoy",
        "Quien termina su novela no es el más rápido, es el más constante. ¡Sigue!",
        "Hay lectores esperando tu historia. No los hagas esperar demasiado",
        "Un pequeño avance hoy es una gran novela mañana",
        "¿Música de fondo para la escena final de «{p}»? Queda genial",
        "Revisa los retoques que le faltan a «{p}» y compártelo con el mundo",
        "No dejes tu historia en pausa. ¡Los personajes cuentan contigo!",
        "¿Qué final le darás a tu novela? Hoy puede ser el día de decidirlo",
        "Tu creatividad no se oxida, pero se acumula. ¡Escribe algo hoy!",
        "Prueba tu novela desde el inicio y descubre qué le falta",
        "Un detalle más y «{p}» quedará perfecto",
        "Cada proyecto terminado te hace mejor creador. ¡Ve por el siguiente paso!",
        "Es hora de dar un último empujón a tu novela visual",
        "Tu novela visual puede ser la favorita de alguien. ¡Termínala!",
        "¿Cuántas escenas tiene ya «{p}»? Seguro puedes agregar una más",
        "Hoy te toca brillar: abre Novela Maker y crea algo increíble"
    )

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Recordatorios de Novela Maker", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun enabled(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun send(ctx: Context, title: String, text: String, open: Intent? = null) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        ensureChannel(ctx)
        val id = (System.currentTimeMillis() % 100000).toInt()
        val intent = open ?: Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_n)
            .setLargeIcon(BitmapFactory.decodeResource(ctx.resources, R.drawable.notif_large))
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, n) } catch (e: SecurityException) { }
    }

    fun projects(ctx: Context): List<String> {
        val raw = ctx.getSharedPreferences("nm", Context.MODE_PRIVATE).getString("projects", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() }
        } catch (e: Exception) { emptyList() }
    }

    fun sendReminder(ctx: Context) {
        val sp = ctx.getSharedPreferences("nm", Context.MODE_PRIVATE)
        val projects = projects(ctx)
        val pool = if (projects.isEmpty()) MESSAGES.filter { !it.contains("{p}") } else MESSAGES
        val i = sp.getInt("msg_i", 0)
        sp.edit().putInt("msg_i", i + 1).apply()
        val text = pool[i % pool.size].replace("{p}", if (projects.isEmpty()) "" else projects.random())
        send(ctx, "Novela Maker", text)
    }

    /** Un recordatorio cada 48 horas. */
    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(48, TimeUnit.HOURS)
            .setInitialDelay(48, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("nm_reminders", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class ReminderWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Notif.sendReminder(applicationContext)
        return Result.success()
    }
}
