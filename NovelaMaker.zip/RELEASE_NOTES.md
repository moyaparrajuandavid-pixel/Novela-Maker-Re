Novedades de la 1.2

- Respaldo automático de tus proyectos en Documentos/NovelaMaker/Respaldo, con opción Restaurar (botón ⚙)
- El menú de pausa ya no se oscurece al tocarlo muchas veces
- Catálogo de 27 fuentes con vista previa y nombres en español
- Emojis para personajes mudos
- Retraso configurable de las voces y del texto
- El video de fondo se ve en el editor, con ajuste a la pantalla y sonido configurable
- Barra de tiempo opcional y escena por defecto si el jugador no elige
- Corregido: el aviso de actualización apuntaba al repositorio equivocado
