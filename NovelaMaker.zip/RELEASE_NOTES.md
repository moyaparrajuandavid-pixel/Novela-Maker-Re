Novedades de la 1.1

- Nueva opción de orientación: automática (sigue al celular), vertical u horizontal
- Botón ⟳ en pantalla para cambiarla; puedes arrastrarlo al lugar que quieras
- Se recuerda tu elección al volver a abrir la app
