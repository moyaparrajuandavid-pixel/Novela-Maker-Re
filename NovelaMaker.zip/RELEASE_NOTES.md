Novedades de la 1.3

- Ya no salta al inicio de la pantalla al tocar una opción en el editor
- Nuevo estilo de texto cómic / manhwa (burbuja con borde y sombra)
- Fuente y caja del texto por escena; fuente del título y menús en Inicio
- Cada diálogo puede tener su propia voz, y se pueden poner varios diálogos en una misma escena
- Se quitó la voz de los sonidos de escena (los proyectos viejos siguen funcionando)
