Primera versión de la app de Novela Maker (editor 2.2).

- Editor de novelas visuales dentro de una app instalable, en horizontal
- Permisos de archivos y notificaciones al entrar
- Recordatorios cada 48 horas para animarte a terminar tu proyecto
- Aviso dentro de la app cuando haya una actualización nueva
